# Landing Page Shopee Affiliate

Landing page statis siap dipasang di GitHub Pages.

## Upload ke GitHub
1. Buat repository baru, misalnya `landing-shopee`.
2. Upload `index.html`.
3. Buka **Settings → Pages**.
4. Pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Klik **Save** dan tunggu GitHub Pages menerbitkan website.

Semua tombol CTA sudah memakai link Shopee affiliate yang diberikan.
